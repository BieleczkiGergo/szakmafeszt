#! /bin/python

from http.server import BaseHTTPRequestHandler, HTTPServer
import atexit
import controls

HOSTNAME = "192.168.0.80"
PORT = 8080
valid_files = ("index.html", "style.css", "svgstyle.css", "script.js", "forward.svg", "backward.svg", "left.svg", "right.svg")
valid_actions = ("forward", "backward", "left", "right")


def get_file_data(fname):
    file = open("web_src/" + fname)
    return "".join(file.readlines())

def get_content_type(fname):
    match fname:
        case "index.html":
            return "text/html"
        case "style.css":
            return "text/css"
        case "script.js":
            return "application/javascript"
        case "up.svg" | "down.svg" | "left.svg" | "right.svg":
            return "image/svg+xml"
        case _:
            return ""


class RobotHTTPHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = self.path[1:]
        if path in valid_files:
            data = bytes(get_file_data(path), "utf-8")
            self.send_response(200)
            self.send_header("content-type", get_content_type(path))
            self.send_header("content-length", len(data))
            self.end_headers()
            self.wfile.write(data)
        else:
            self.send_response(404)
            self.send_header("content-type", "text/plain")
            self.send_header("content-length", "0")
            self.end_headers()
        self.close_connection = True

    def do_POST(self):
        path = self.path[1:]
        if path in valid_actions:
            self.send_response(200)
            content_len = int(self.headers.get("content-length", 0))
            body = self.rfile.read(content_len).decode("utf-8")[0]
            controls.control_robot(path[0], body)
            
        else:
            self.send_response(404)
        self.send_header("content-type", "text/plain")
        self.send_header("content-length", "0")
        self.end_headers()
        self.close_connection = True


web_server = HTTPServer((HOSTNAME, PORT), RobotHTTPHandler)

def start_server():
    web_server.serve_forever()

def stop_server():
    web_server.server_close()

