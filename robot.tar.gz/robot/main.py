#! /bin/python

import server
import controls
import atexit

def exit():
    server.stop_server()

atexit.register(exit)

if __name__ == "__main__":
    server.start_server()