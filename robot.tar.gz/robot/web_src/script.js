const buttons = ["left", "right", "forward", "backward"];

class RobotAction{
    constructor(direction){
        this.direction = direction;
        this.element = document.getElementById(direction);

        this.element.addEventListener("mousedown", () => {
            this.down();

        });

        this.element.addEventListener("mouseup", () => {
            this.up();

        });

    }

    async up(){
        const resp = await fetch(this.direction, {
            method: "post",
            body: "u",
    
        });
        console.log(this.direction, "up, response arrived");

    }

    async down(){
        const resp = fetch(this.direction, {
            method: "post",
            body: "d"
        });
        console.log(this.direction, "down, response arrived");

    }
}

const actions = buttons.map((item) => {
    return new RobotAction(item);

});
